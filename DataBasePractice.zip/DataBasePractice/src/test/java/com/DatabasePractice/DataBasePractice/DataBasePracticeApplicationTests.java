package com.DatabasePractice.DataBasePractice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataBasePracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
